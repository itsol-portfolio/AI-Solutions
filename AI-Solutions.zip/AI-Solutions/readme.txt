AI-Solutions sample dataset and Python script.
Demonstrates linear regression using scikit-learn.
